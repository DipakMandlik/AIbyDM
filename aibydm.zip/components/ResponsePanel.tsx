import React, { useState } from 'react';
import { 
  Trophy, 
  Copy,
  Check,
  Code2,
  AlertCircle,
  Zap,
  Globe,
  Terminal,
  Sparkles,
  Image as ImageIcon,
  Layers,
  MessageSquare,
  Bot,
  Network,
  Maximize2
} from 'lucide-react';
import { OrchestrationResult, Platform } from '../types';

interface ResponsePanelProps {
  result: OrchestrationResult;
  mode: 'prompt' | 'orchestrate' | 'research' | 'sql' | 'schema' | 'debug' | 'visual' | 'news' | 'social';
}

const ModelLogo = ({ platform, className }: { platform: string, className?: string }) => {
    const size = className || "w-4 h-4";
    switch (platform) {
        case Platform.GEMINI: return <Sparkles className={`${size} text-blue-600 fill-blue-600/20`} />;
        case Platform.CHATGPT: return <Zap className={`${size} text-green-500 fill-green-500/20`} />;
        case Platform.PERPLEXITY: return <Globe className={`${size} text-teal-500`} />;
        case Platform.DEEPSEEK: return <Terminal className={`${size} text-purple-600`} />;
        case Platform.CLAUDE: return <Bot className={`${size} text-orange-600`} />;
        default: return <Code2 className={`${size} text-gray-500`} />;
    }
};

export const ResponsePanel: React.FC<ResponsePanelProps> = ({ result, mode }) => {
  const [selectedPlatform, setSelectedPlatform] = useState<Platform>(
    result.evaluation.recommended_response as Platform || Platform.GEMINI
  );
  const [viewMode, setViewMode] = useState<'answer' | 'compare'>('answer');
  const [copied, setCopied] = useState(false);

  const activeResponse = result.responses.find(r => r.platform === selectedPlatform) || result.responses[0];
  const activeRanking = result.evaluation.rankings.find(r => r.platform === selectedPlatform);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const extractCode = (content: string) => {
    const match = content.match(/```(\w+)?\n([\s\S]*?)```/);
    if (match) {
        return { language: match[1] || 'text', code: match[2] };
    }
    return { language: 'text', code: content }; 
  };

  const extractPrompt = (content: string) => {
      const promptMatch = content.match(/# Optimized Prompt\s*\n([\s\S]*?)(?:\n#|$)/);
      const explanationMatch = content.match(/# Explanation\s*\n([\s\S]*?)$/);
      return {
          prompt: promptMatch ? promptMatch[1].trim() : content,
          explanation: explanationMatch ? explanationMatch[1].trim() : ''
      };
  }

  // --- RENDERERS ---

  const renderResearchMode = () => (
    <div className="relative group animate-in fade-in duration-500">
        <div className="prose prose-slate max-w-none prose-p:leading-relaxed prose-p:text-gray-700 prose-headings:font-semibold prose-headings:text-gray-900 prose-pre:bg-gray-50 prose-pre:border prose-pre:border-gray-200">
            <div className="whitespace-pre-wrap text-[15px] leading-7 font-normal">
                {activeResponse?.content.split('\n').map((line, i) => (
                    <p key={i} className="mb-3">{line}</p>
                ))}
            </div>
        </div>
    </div>
  );

  const renderCodeMode = () => {
    const { language, code } = activeResponse ? extractCode(activeResponse.content) : { language: 'text', code: '' };
    const explanation = activeResponse?.content.replace(/```[\s\S]*?```/g, '').trim() || '';

    return (
        <div className="flex flex-col gap-6 animate-in slide-in-from-bottom-2 duration-500">
            <div className="rounded-lg overflow-hidden shadow-lg border border-gray-800 bg-[#0d1117] flex flex-col font-mono text-sm">
                <div className="flex items-center justify-between px-4 py-2 bg-[#161b22] border-b border-[#30363d]">
                    <div className="flex items-center gap-3">
                        <span className="text-[#8b949e] text-xs uppercase font-bold tracking-wider">
                            {language || (mode === 'sql' ? 'SQL' : 'PYTHON')}
                        </span>
                    </div>
                    <button 
                        onClick={() => handleCopy(code)} 
                        className="text-xs text-[#8b949e] hover:text-white flex items-center gap-1.5 transition-colors"
                    >
                        {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                        {copied ? 'Copied' : 'Copy'}
                    </button>
                </div>
                <div className="flex overflow-x-auto max-h-[500px] custom-scrollbar p-4">
                    <pre className="text-[#c9d1d9] leading-6 whitespace-pre tab-4">
                        {code}
                    </pre>
                </div>
            </div>
            {explanation && (
                <div className="bg-white border border-gray-200 rounded-lg p-5 shadow-sm">
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-3 flex items-center gap-2">
                        <Terminal className="w-3.5 h-3.5 text-blue-600" /> 
                        Analysis
                    </h3>
                    <div className="prose prose-sm max-w-none text-gray-600">
                        <div className="whitespace-pre-wrap">{explanation}</div>
                    </div>
                </div>
            )}
        </div>
    );
  };

  const renderPromptMode = () => {
      const { prompt, explanation } = activeResponse ? extractPrompt(activeResponse.content) : { prompt: '', explanation: '' };

      return (
          <div className="flex flex-col gap-6 animate-in slide-in-from-bottom-2 duration-500">
              <div className="bg-white border border-indigo-100 rounded-xl p-8 shadow-md shadow-indigo-50 relative group">
                  <div className="absolute top-4 right-4 opacity-100 lg:opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => handleCopy(prompt)}
                        className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg text-xs font-bold hover:bg-indigo-100 transition-all"
                      >
                          {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          Copy
                      </button>
                  </div>
                  <div className="flex items-center gap-2 mb-4">
                      <div className="p-1.5 bg-indigo-50 rounded-lg text-indigo-600">
                          <MessageSquare className="w-4 h-4" />
                      </div>
                      <h3 className="text-xs font-bold text-indigo-900 uppercase tracking-wider">Optimized Prompt</h3>
                  </div>
                  <div className="text-base text-gray-800 leading-relaxed font-medium whitespace-pre-wrap font-sans">
                      {prompt}
                  </div>
              </div>
              <div className="bg-gray-50 rounded-xl p-6 border border-gray-200">
                   <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-2">
                       <Layers className="w-3.5 h-3.5" /> Strategy
                   </h3>
                   <p className="text-sm text-gray-600 leading-relaxed whitespace-pre-wrap">{explanation}</p>
              </div>
          </div>
      );
  };

  const renderVisualMode = () => {
    if (activeResponse?.type === 'image') {
        return (
            <div className="flex flex-col items-center gap-6 animate-in zoom-in-95 duration-500">
                <div className="bg-white p-2 rounded-xl border border-gray-200 shadow-xl shadow-gray-200/50 w-full">
                     <img 
                        src={`data:image/png;base64,${activeResponse.content}`} 
                        alt="Generated" 
                        className="rounded-lg w-full max-h-[500px] object-contain bg-gray-50"
                     />
                </div>
            </div>
        );
    } else if (activeResponse?.type === 'graph' && activeResponse.meta) {
        const { nodes, edges } = activeResponse.meta;
        if (!nodes || !edges) return <div className="text-red-500">Invalid Graph Data</div>;

        const width = 800;
        const height = 500;
        const centerX = width / 2;
        const centerY = height / 2;
        const radius = 150;
        
        const nodePositions = nodes.map((n: any, i: number) => {
            const angle = (i / nodes.length) * 2 * Math.PI;
            return {
                ...n,
                x: centerX + radius * Math.cos(angle) + (Math.random() * 40 - 20),
                y: centerY + radius * Math.sin(angle) + (Math.random() * 40 - 20)
            };
        });

        return (
            <div className="flex flex-col gap-6 animate-in slide-in-from-bottom-2 duration-500">
                <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm overflow-x-auto flex justify-center items-center bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px]">
                     <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="min-w-[600px]">
                        {edges.map((e: any, i: number) => {
                            const source = nodePositions.find((n: any) => n.id === e.source);
                            const target = nodePositions.find((n: any) => n.id === e.target);
                            if (!source || !target) return null;
                            return (
                                <g key={i}>
                                    <line 
                                        x1={source.x} y1={source.y} 
                                        x2={target.x} y2={target.y} 
                                        stroke="#cbd5e1" strokeWidth="1" 
                                    />
                                    <text x={(source.x + target.x)/2} y={(source.y + target.y)/2} fill="#94a3b8" fontSize="10" textAnchor="middle" className="bg-white px-1">{e.label}</text>
                                </g>
                            );
                        })}
                        {nodePositions.map((n: any) => (
                            <g key={n.id}>
                                <circle cx={n.x} cy={n.y} r="24" fill="white" stroke={n.type === 'main' ? '#2563eb' : '#94a3b8'} strokeWidth={n.type === 'main' ? 2 : 1} className="drop-shadow-sm transition-all hover:r-28" />
                                <text x={n.x} y={n.y} dy="4" textAnchor="middle" fontSize="10" className="font-semibold fill-gray-800 pointer-events-none">{n.label.substring(0, 8)}</text>
                            </g>
                        ))}
                     </svg>
                </div>
            </div>
        );
    }
    return renderResearchMode();
  };

  return (
    <div className="w-full">
      {/* HEADER TABS */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-4">
          <div className="flex bg-gray-100/50 p-1 rounded-lg border border-gray-200/50 self-start">
             <button onClick={() => setViewMode('answer')} className={`px-4 py-1.5 rounded-md text-xs font-medium transition-all ${viewMode === 'answer' ? 'bg-white shadow-sm text-gray-900 border border-gray-200' : 'text-gray-500 hover:text-gray-900'}`}>Recommended</button>
             <button onClick={() => setViewMode('compare')} className={`px-4 py-1.5 rounded-md text-xs font-medium transition-all ${viewMode === 'compare' ? 'bg-white shadow-sm text-gray-900 border border-gray-200' : 'text-gray-500 hover:text-gray-900'}`}>All Models</button>
          </div>
          
          {activeRanking && (
             <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 border border-green-100 rounded-full text-xs font-medium text-green-700 self-start sm:self-auto">
                 <Trophy className="w-3.5 h-3.5" />
                 Score: {activeRanking.total_score}/10
             </div>
          )}
      </div>

      {viewMode === 'answer' ? (
        <div className="relative group">
            {/* PLATFORM HEADER */}
            <div className="flex items-center gap-3 mb-6">
                 <div className="w-10 h-10 rounded-xl bg-white border border-gray-200 flex items-center justify-center shadow-sm">
                     <ModelLogo platform={selectedPlatform} className="w-5 h-5" />
                 </div>
                 <div>
                     <div className="text-sm font-semibold text-gray-900">{selectedPlatform}</div>
                     <div className="text-xs text-gray-500 flex items-center gap-2">
                         <span>v3.5</span>
                         <span className="w-1 h-1 rounded-full bg-gray-300" />
                         <span>{activeResponse?.latency?.toFixed(0) || '200'}ms</span>
                     </div>
                 </div>
            </div>

            <div className="min-h-[200px]">
                {(mode === 'sql' || mode === 'debug' || mode === 'schema') ? renderCodeMode() 
                : mode === 'prompt' ? renderPromptMode() 
                : mode === 'visual' ? renderVisualMode()
                : renderResearchMode()}
            </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             {result.evaluation.rankings.sort((a,b) => b.total_score - a.total_score).map((rank) => (
                 <div key={rank.platform} onClick={() => { setSelectedPlatform(rank.platform as Platform); setViewMode('answer'); }} className={`p-5 rounded-xl border cursor-pointer transition-all hover:shadow-md ${selectedPlatform === rank.platform ? 'border-blue-500 ring-1 ring-blue-500 bg-blue-50/10' : 'border-gray-200 bg-white hover:border-gray-300'}`}>
                     <div className="flex justify-between items-start mb-3">
                         <div className="flex items-center gap-3">
                             <ModelLogo platform={rank.platform} className="w-5 h-5" />
                             <span className="font-semibold text-gray-900">{rank.platform}</span>
                         </div>
                         <div className="text-lg font-bold text-gray-900">{rank.total_score}</div>
                     </div>
                     <p className="text-xs text-gray-500 line-clamp-3 leading-relaxed">{rank.reasoning}</p>
                 </div>
             ))}
        </div>
      )}
    </div>
  );
};