import React from 'react';
import { X, Key, Zap, Shield, CheckCircle, Database } from 'lucide-react';

interface SettingsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  apiKeys: {
    openai: string;
    perplexity: string;
    deepseek: string;
    claude: string;
  };
  setApiKeys: React.Dispatch<React.SetStateAction<{
    openai: string;
    perplexity: string;
    deepseek: string;
    claude: string;
  }>>;
}

export const SettingsDrawer: React.FC<SettingsDrawerProps> = ({ isOpen, onClose, apiKeys, setApiKeys }) => {
  if (!isOpen) return null;

  const handleChange = (key: keyof typeof apiKeys, value: string) => {
    setApiKeys(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div 
        className="absolute inset-0 bg-gray-900/40 backdrop-blur-sm"
        onClick={onClose}
      />
      
      <div className="relative w-full max-w-md bg-white border-l border-gray-200 h-full shadow-2xl overflow-y-auto animate-in slide-in-from-right duration-300">
        <div className="p-6">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <Zap className="w-5 h-5 text-aibydm-primary" />
              Settings & Integrations
            </h2>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-400 hover:text-gray-900"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-8">
            {/* Simulation Mode Info */}
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                <div className="flex items-start gap-3">
                    <Database className="w-5 h-5 text-blue-600 mt-0.5" />
                    <div>
                        <h3 className="font-semibold text-blue-900 text-sm">Smart Simulation Active</h3>
                        <p className="text-xs text-blue-700 mt-1 leading-relaxed">
                            To prevent "Quota Exceeded" errors and allow unlimited testing, the system will automatically switch to <strong>Simulation Mode</strong> if API limits are reached.
                        </p>
                    </div>
                </div>
            </div>

            {/* API Keys Section */}
            <div className="space-y-4">
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
                <Key className="w-4 h-4" /> Provider Connections
              </h3>
              
              <div className="space-y-3">
                <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-semibold text-green-900 text-sm">Google Gemini</span>
                    <span className="text-[10px] bg-green-200 text-green-800 px-2 py-0.5 rounded font-bold uppercase">System Key</span>
                  </div>
                  <div className="text-xs text-green-700 font-mono">Primary Orchestrator</div>
                </div>

                {[
                  { id: 'openai', label: 'OpenAI' },
                  { id: 'perplexity', label: 'Perplexity' },
                  { id: 'deepseek', label: 'DeepSeek' },
                  { id: 'claude', label: 'Anthropic' }
                ].map((provider) => {
                  const keyId = provider.id as keyof typeof apiKeys;
                  const isConnected = apiKeys[keyId]?.length > 5;

                  return (
                    <div key={provider.id} className={`p-4 rounded-lg border transition-all ${isConnected ? 'bg-white border-blue-200 shadow-sm' : 'bg-gray-50 border-gray-100'}`}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium text-gray-700 text-sm">{provider.label}</span>
                        {isConnected ? (
                             <span className="flex items-center gap-1 text-[10px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded font-bold uppercase">
                                <CheckCircle className="w-3 h-3" /> Connected
                             </span>
                        ) : (
                             <span className="text-[10px] bg-gray-200 text-gray-500 px-2 py-0.5 rounded font-bold uppercase">Inactive</span>
                        )}
                      </div>
                      <input 
                        type="password" 
                        value={apiKeys[keyId] || ''}
                        onChange={(e) => handleChange(keyId, e.target.value)}
                        placeholder={`Paste API Key (Optional)`}
                        className={`w-full bg-white border rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all ${isConnected ? 'border-gray-200 text-gray-900' : 'border-gray-200 text-gray-600'}`}
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};