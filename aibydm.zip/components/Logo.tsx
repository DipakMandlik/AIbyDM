import React from 'react';

export const Logo = ({ className = "w-8 h-8", collapsed = false }: { className?: string, collapsed?: boolean }) => {
  return (
    <div className={`flex items-center gap-3 ${collapsed ? 'justify-center' : ''}`}>
      <div className={`relative flex items-center justify-center ${className} shrink-0`}>
        <svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
          <defs>
            <linearGradient id="logoGradient" x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse">
              <stop stopColor="#2563eb" />
              <stop offset="1" stopColor="#7c3aed" />
            </linearGradient>
            <filter id="glow" x="-4" y="-4" width="48" height="48" filterUnits="userSpaceOnUse">
              <feGaussianBlur stdDeviation="2" result="effect1_foregroundBlur" />
            </filter>
          </defs>
          
          {/* Glow Effect */}
          <path d="M20 4L34 12V28L20 36L6 28V12L20 4Z" fill="url(#logoGradient)" fillOpacity="0.2" filter="url(#glow)" />
          
          {/* Main Hexagon Structure */}
          <path d="M20 6L32 13V27L20 34L8 27V13L20 6Z" stroke="url(#logoGradient)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="white" />
          
          {/* Inner Connections */}
          <path d="M20 14V26M14 17L26 23M26 17L14 23" stroke="url(#logoGradient)" strokeWidth="2" strokeLinecap="round" />
          
          {/* Central Node */}
          <circle cx="20" cy="20" r="3" fill="#0f172a" />
        </svg>
      </div>
      
      {!collapsed && (
        <div className="flex flex-col">
          <span className="font-bold text-lg tracking-tight text-gray-900 leading-none">AIBYDM</span>
          <span className="text-[9px] font-semibold tracking-widest text-blue-600 uppercase mt-0.5">Orchestration</span>
        </div>
      )}
    </div>
  );
};