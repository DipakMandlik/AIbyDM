import React from 'react';
import { NewsItem } from '../types';
import { Clock, ExternalLink, Share2, Zap } from 'lucide-react';

interface NewsFeedProps {
  news: NewsItem[];
  onGeneratePost: (item: NewsItem) => void;
  loading: boolean;
}

export const NewsFeed: React.FC<NewsFeedProps> = ({ news, onGeneratePost, loading }) => {
  if (loading) {
      return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
              {[1,2,3,4,5,6].map(i => (
                  <div key={i} className="h-64 bg-gray-100 rounded-xl"></div>
              ))}
          </div>
      );
  }

  return (
    <div className="space-y-6">
        <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                Latest 24h Intelligence
            </h2>
            <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">Updated: Just now</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {news.map((item) => (
                <div key={item.id} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-shadow group flex flex-col h-full">
                    <div className="flex justify-between items-start mb-4">
                        <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${
                            item.impact === 'High' ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'
                        }`}>
                            {item.category} • {item.impact} Impact
                        </span>
                        <Clock className="w-3.5 h-3.5 text-gray-400" />
                    </div>
                    
                    <h3 className="text-lg font-bold text-gray-900 mb-2 leading-tight group-hover:text-blue-600 transition-colors">
                        {item.title}
                    </h3>
                    
                    <p className="text-sm text-gray-600 mb-6 flex-1 line-clamp-3">
                        {item.summary}
                    </p>
                    
                    <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                        <span className="text-xs text-gray-400 font-medium">{item.source}</span>
                        <button 
                            onClick={() => onGeneratePost(item)}
                            className="flex items-center gap-2 px-3 py-1.5 bg-black text-white rounded-lg text-xs font-medium hover:bg-gray-800 transition-colors"
                        >
                            <Share2 className="w-3.5 h-3.5" />
                            Create Post
                        </button>
                    </div>
                </div>
            ))}
        </div>
    </div>
  );
};