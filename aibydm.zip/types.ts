export enum Platform {
  GEMINI = 'Gemini',
  CHATGPT = 'ChatGPT',
  PERPLEXITY = 'Perplexity',
  DEEPSEEK = 'DeepSeek',
  CLAUDE = 'Claude'
}

export type SourceType = 'text' | 'image' | 'url' | 'table';

export interface Source {
  id: string;
  name: string;
  type: SourceType;
  content: string; // Base64 for images, raw text for files
  mimeType?: string; // e.g., 'image/png', 'text/csv'
}

export interface EnhancedPrompts {
  gemini: string;
  chatgpt: string;
  perplexity: string;
  deepseek: string;
  claude: string;
  taskType: string;
}

export interface AIResponse {
  platform: Platform;
  content: string;
  latency: number;
  tokensUsed?: number;
  type?: 'text' | 'image' | 'graph'; 
  meta?: any; 
}

export interface EvaluationScore {
  accuracy: number;
  completeness: number;
  clarity: number;
  relevance: number;
}

export interface Ranking {
  platform: Platform;
  total_score: number;
  breakdown: EvaluationScore;
  reasoning: string;
}

export interface EvaluationResult {
  rankings: Ranking[];
  recommended_response: Platform;
  confidence: number;
}

export interface OrchestrationResult {
  originalQuery: string;
  enhancedPrompts: EnhancedPrompts;
  responses: AIResponse[];
  evaluation: EvaluationResult;
}

// --- NEW TYPES ---

export interface NewsItem {
  id: string;
  title: string;
  summary: string;
  source: string;
  timestamp: string;
  category: 'AI' | 'Data' | 'Cloud' | 'Hardware';
  impact: 'High' | 'Medium' | 'Low';
}

export interface SocialPost {
  platform: 'LinkedIn' | 'Instagram' | 'Twitter';
  caption: string;
  imagePrompt: string;
  hashtags: string[];
  generatedImage?: string; // Base64
}