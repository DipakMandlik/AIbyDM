import React, { useState, useRef, useEffect } from 'react';
import { Settings, Sparkles, Command, ArrowRight, Loader2, Bug, MessageSquare, Database, FileJson, Layers, Wand2, Play, Eraser, Upload, FileText, Image as ImageIcon, X, BookOpen, Plus, Table, Search, ChevronLeft, ChevronRight, Home, Compass, Library, History, Globe, Code, Network, BrainCircuit, Newspaper, Share2, Check, LayoutGrid, Menu, Bell, HelpCircle, User, Zap } from 'lucide-react';
import { SettingsDrawer } from './components/SettingsDrawer';
import { ResponsePanel } from './components/ResponsePanel';
import { NewsFeed } from './components/NewsFeed';
import { Toast } from './components/Toast';
import { Logo } from './components/Logo';
import { OrchestrationResult, Source, SourceType, Platform, NewsItem, SocialPost } from './types';
import { enhancePrompts, distributeQueries, evaluateResponses, getTechNews, generateSocialPost } from './services/geminiService';
import { requestNotificationPermission, sendNotification, playNotificationSound } from './services/notificationService';

type ToolMode = 'prompt' | 'orchestrate' | 'research' | 'sql' | 'schema' | 'debug' | 'visual' | 'news' | 'social';

function App() {
  // --- STATE ---
  const [mode, setMode] = useState<ToolMode>('research');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [toast, setToast] = useState<{msg: string, type: 'success' | 'error'} | null>(null);
  const [hasUnreadNotifications, setHasUnreadNotifications] = useState(true);

  // Inputs
  const [mainInput, setMainInput] = useState(''); 
  const [contextInput, setContextInput] = useState('');
  const [showContext, setShowContext] = useState(false);
  const [sources, setSources] = useState<Source[]>([]);
  
  // Settings & Data
  const [activePlatforms, setActivePlatforms] = useState<Platform[]>([
      Platform.GEMINI, Platform.CHATGPT, Platform.PERPLEXITY, Platform.DEEPSEEK, Platform.CLAUDE
  ]);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [loadingStep, setLoadingStep] = useState<string | null>(null);
  const [result, setResult] = useState<OrchestrationResult | null>(null);
  const [apiKeys, setApiKeys] = useState({ openai: '', perplexity: '', deepseek: '', claude: '' });
  
  // Feature Specific
  const [news, setNews] = useState<NewsItem[]>([]);
  const [socialPost, setSocialPost] = useState<SocialPost | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // --- EFFECTS ---

  useEffect(() => {
    requestNotificationPermission();
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem('nexus_state');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.result) setResult(parsed.result);
        if (parsed.mode) setMode(parsed.mode);
      } catch (e) { localStorage.removeItem('nexus_state'); }
    }
  }, []);

  useEffect(() => {
    if (result) {
      localStorage.setItem('nexus_state', JSON.stringify({ result, mode }));
    }
  }, [result, mode]);

  useEffect(() => {
      if (mode === 'news' && news.length === 0) {
          setLoadingStep('fetching news');
          getTechNews().then(items => {
              setNews(items);
              setLoadingStep(null);
          });
      }
  }, [mode]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [mainInput]);

  // --- HANDLERS ---

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToast({ msg, type });
  };

  const togglePlatform = (p: Platform) => {
      setActivePlatforms(prev => prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]);
  };

  const handleNewsPostGeneration = async (item: NewsItem) => {
      setMode('social');
      setLoadingStep('generating_social');
      try {
          const post = await generateSocialPost(item, 'LinkedIn');
          setSocialPost(post);
          showToast("Social post draft created!");
      } catch(e) {
          showToast("Failed to generate post", 'error');
      } finally {
          setLoadingStep(null);
      }
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if ((!mainInput.trim() && sources.length === 0) || loadingStep) return;
    
    setResult(null);
    setIsMobileMenuOpen(false); 
    
    try {
      setLoadingStep('enhancing');
      const effectiveMode = mode === 'social' ? 'visual' : mode; 
      const enhancedPrompts = await enhancePrompts(mainInput, effectiveMode, sources);

      setLoadingStep('distributing');
      const responses = await distributeQueries(enhancedPrompts, effectiveMode, sources, activePlatforms);

      setLoadingStep('evaluating');
      const evaluation = await evaluateResponses(mainInput, responses, enhancedPrompts.taskType);

      const finalResult = {
        originalQuery: mainInput,
        enhancedPrompts,
        responses,
        evaluation
      };

      setResult(finalResult);
      sendNotification("Task Complete", `AIBYDM Agents finished: ${enhancedPrompts.taskType}`);
      playNotificationSound();
      setHasUnreadNotifications(true);

    } catch (error) {
      console.error("Workflow failed", error);
      showToast("Something went wrong. Try again.", 'error');
    } finally {
      setLoadingStep(null);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();

      reader.onload = (event) => {
        const content = event.target?.result;
        if (typeof content === 'string') {
          let type: SourceType = 'text';
          let processedContent = content;

          if (file.type.startsWith('image/')) {
            type = 'image';
            processedContent = content.split(',')[1];
            setMode('visual'); 
            showToast("Image uploaded. Switched to Visual Mode.");
          } else {
            showToast("File attached successfully.");
          }

          setSources(prev => [...prev, {
            id: Date.now().toString(),
            name: file.name,
            type,
            content: processedContent,
            mimeType: file.type
          }]);
        }
      };

      if (file.type.startsWith('image/')) reader.readAsDataURL(file);
      else reader.readAsText(file);
    }
  };

  const removeSource = (id: string) => {
    setSources(prev => prev.filter(s => s.id !== id));
  };

  const getPlaceholder = () => {
    switch (mode) {
      case 'sql': return 'Paste raw SQL or describe query requirements...';
      case 'debug': return 'Paste broken code snippet or stacktrace...';
      case 'prompt': return 'Draft your prompt here to optimize...';
      case 'visual': return 'Describe image to generate or ask about upload...';
      case 'social': return 'Describe the post you want to create...';
      default: return 'Ask a research question or complex query...';
    }
  };

  const getModeLabel = (m: ToolMode) => {
      switch(m) {
          case 'sql': return 'SQL Architect';
          case 'debug': return 'Code Debugger';
          case 'visual': return 'Visual Studio';
          case 'prompt': return 'Prompt Lab';
          case 'news': return 'Tech Pulse';
          case 'social': return 'Social Studio';
          default: return 'Research';
      }
  }

  // --- COMPONENT HELPERS ---
  
  const NavButton = ({ targetMode, icon, label }: { targetMode: ToolMode, icon: any, label: string }) => (
    <button
      onClick={() => { setMode(targetMode); setIsMobileMenuOpen(false); }}
      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all mb-1 ${
        mode === targetMode 
          ? 'bg-blue-50 text-blue-700 font-semibold shadow-sm' 
          : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
      }`}
    >
      <div className={`w-5 h-5 ${mode === targetMode ? 'text-blue-600' : 'text-gray-400'}`}>
        {React.cloneElement(icon, { className: "w-full h-full" })}
      </div>
      <span className="text-sm">{label}</span>
    </button>
  );

  return (
    <div className="flex h-screen bg-[#f8fafc] text-gray-900 font-sans overflow-hidden">
      
      {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}

      {/* MOBILE OVERLAY */}
      {isMobileMenuOpen && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 lg:hidden animate-in fade-in duration-200" onClick={() => setIsMobileMenuOpen(false)} />
      )}
      
      {/* SIDEBAR */}
      <aside className={`
          fixed inset-y-0 left-0 z-50 w-[280px] bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out shadow-2xl lg:shadow-none lg:relative lg:translate-x-0
          ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="flex flex-col h-full">
            {/* Sidebar Header */}
            <div className="h-16 flex items-center px-6 border-b border-gray-100/50">
                 <Logo />
                 <button onClick={() => setIsMobileMenuOpen(false)} className="lg:hidden ml-auto p-1 text-gray-400 hover:text-gray-900">
                    <X className="w-6 h-6" />
                </button>
            </div>

            <div className="px-4 py-6">
                <button 
                    onClick={() => { setResult(null); setMainInput(''); setNews([]); setIsMobileMenuOpen(false); }}
                    className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl py-3 px-4 flex items-center justify-center gap-2 transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5 active:translate-y-0"
                >
                    <Plus className="w-5 h-5" />
                    <span className="font-semibold text-sm">New Thread</span>
                </button>
            </div>

            <div className="flex-1 overflow-y-auto px-4 space-y-1 custom-scrollbar">
                <div className="px-3 py-2 text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-2">Workspace</div>
                <NavButton targetMode="research" icon={<Search />} label="Deep Research" />
                <NavButton targetMode="orchestrate" icon={<Compass />} label="Orchestrator" />
                <NavButton targetMode="news" icon={<Newspaper />} label="Tech Pulse" />
                
                <div className="px-3 py-2 text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-6">Studio Tools</div>
                <NavButton targetMode="prompt" icon={<Wand2 />} label="Prompt Lab" />
                <NavButton targetMode="visual" icon={<ImageIcon />} label="Visual Studio" />
                <NavButton targetMode="social" icon={<Share2 />} label="Social Studio" />
                <NavButton targetMode="sql" icon={<Database />} label="SQL Architect" />
                <NavButton targetMode="debug" icon={<Bug />} label="Debugger" />
            </div>

            <div className="p-4 border-t border-gray-100 bg-gray-50/30">
                <button onClick={() => { setIsSettingsOpen(true); setIsMobileMenuOpen(false); }} className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-white hover:shadow-sm text-gray-600 transition-all border border-transparent hover:border-gray-200">
                    <Settings className="w-5 h-5" />
                    <div className="flex flex-col items-start">
                        <span className="font-semibold text-sm text-gray-900">Config & Keys</span>
                        <span className="text-[10px] text-gray-500">Manage integrations</span>
                    </div>
                </button>
            </div>
        </div>
      </aside>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 flex flex-col relative min-w-0 bg-[#f8fafc]">
        
        {/* UNIFIED TOP NAVBAR (Desktop & Mobile) */}
        <header className="h-16 bg-white/80 backdrop-blur-xl border-b border-gray-200 flex items-center justify-between px-4 lg:px-8 sticky top-0 z-30 transition-all">
            <div className="flex items-center gap-4 min-w-0">
                <button onClick={() => setIsMobileMenuOpen(true)} className="lg:hidden p-2 -ml-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                    <Menu className="w-6 h-6" />
                </button>
                
                {/* Context Breadcrumb / Mode Indicator */}
                <div className="flex flex-col">
                    <div className="flex items-center gap-2 text-sm text-gray-500 overflow-hidden">
                        <span className="font-semibold text-gray-900 whitespace-nowrap">{getModeLabel(mode)}</span>
                        {result && <ChevronRight className="w-4 h-4 shrink-0 text-gray-300" />}
                        {result && <span className="truncate max-w-[150px] lg:max-w-md text-gray-600 hidden sm:inline">{result.originalQuery}</span>}
                    </div>
                </div>
            </div>

            {/* Right Side Functionality */}
            <div className="flex items-center gap-1 sm:gap-3">
                 <button className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-all hidden sm:flex">
                     <HelpCircle className="w-5 h-5" />
                 </button>

                 <button 
                    className="p-2 text-gray-400 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-all relative"
                    onClick={() => setHasUnreadNotifications(false)}
                 >
                     <Bell className="w-5 h-5" />
                     {hasUnreadNotifications && (
                         <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 border-2 border-white rounded-full"></span>
                     )}
                 </button>

                 <div className="w-px h-6 bg-gray-200 mx-1 hidden sm:block"></div>

                 <button className="flex items-center gap-3 pl-1 pr-2 py-1 rounded-full hover:bg-gray-100 transition-all">
                     <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center text-white shadow-sm ring-2 ring-white">
                         <User className="w-4 h-4" />
                     </div>
                     <div className="flex-col items-start hidden md:flex">
                         <span className="text-xs font-bold text-gray-900">Admin User</span>
                         <span className="text-[10px] text-green-600 flex items-center gap-1">
                             <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
                             Online
                         </span>
                     </div>
                 </button>
            </div>
        </header>

        {/* SCROLLABLE CONTENT */}
        <div className="flex-1 overflow-y-auto custom-scrollbar scroll-smooth">
          
          {loadingStep && (
              <div className="flex flex-col items-center justify-center min-h-[50vh] animate-in fade-in duration-500">
                  <div className="relative">
                      <div className="w-20 h-20 border-4 border-blue-100 border-t-blue-600 rounded-full animate-spin"></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                          <Logo className="w-8 h-8" collapsed={true} />
                      </div>
                  </div>
                  <h3 className="mt-8 text-xl font-semibold text-gray-900">Orchestrating Agents</h3>
                  <div className="flex items-center gap-2 mt-2 text-sm text-gray-500">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span className="capitalize">{loadingStep.replace('_', ' ')}...</span>
                  </div>
              </div>
          )}

          {/* NEWS MODE */}
          {mode === 'news' && !loadingStep && (
              <div className="max-w-7xl mx-auto px-4 lg:px-8 py-8 pb-32">
                  <NewsFeed news={news} onGeneratePost={handleNewsPostGeneration} loading={loadingStep === 'fetching news'} />
              </div>
          )}

          {/* SOCIAL MODE */}
          {mode === 'social' && socialPost && !loadingStep && (
              <div className="max-w-5xl mx-auto px-4 lg:px-8 py-8 pb-32">
                  <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-xl flex flex-col md:flex-row">
                      <div className="md:w-1/2 bg-gray-50 p-6 flex items-center justify-center min-h-[400px] border-r border-gray-100">
                          {socialPost.generatedImage ? (
                              <img src={`data:image/png;base64,${socialPost.generatedImage}`} alt="Generated" className="w-full h-auto rounded-lg shadow-lg object-cover ring-1 ring-gray-900/5" />
                          ) : (
                              <div className="text-gray-400 flex flex-col items-center">
                                  <ImageIcon className="w-16 h-16 mb-4 opacity-50" />
                                  <span>Image Generation Failed</span>
                              </div>
                          )}
                      </div>
                      <div className="md:w-1/2 p-8 flex flex-col">
                          <div className="flex items-center justify-between mb-6">
                              <div className="flex items-center gap-2">
                                  <div className="w-8 h-8 bg-[#0a66c2] rounded-md flex items-center justify-center text-white">
                                      <Share2 className="w-4 h-4" />
                                  </div>
                                  <span className="font-bold text-gray-900">LinkedIn Draft</span>
                              </div>
                              <span className="text-xs text-gray-400 font-mono">AI-Generated</span>
                          </div>
                          
                          <div className="flex-1 mb-6">
                            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Caption</label>
                            <textarea 
                                className="w-full h-full min-h-[250px] bg-gray-50 rounded-xl p-4 text-sm leading-relaxed border border-gray-200 resize-none focus:outline-none focus:ring-2 focus:ring-blue-100 transition-all text-gray-700"
                                value={socialPost.caption}
                                readOnly
                            />
                          </div>

                          <div className="flex gap-3 mt-auto">
                              <button 
                                onClick={() => showToast("Post scheduled successfully!")}
                                className="flex-1 bg-gray-900 text-white py-3 rounded-xl text-sm font-bold hover:bg-black transition-all shadow-lg shadow-gray-900/20"
                              >
                                Schedule Post
                              </button>
                              <button 
                                className="px-6 py-3 border border-gray-200 rounded-xl text-sm font-medium hover:bg-gray-50 transition-colors text-gray-600" 
                                onClick={() => setSocialPost(null)}
                              >
                                Discard
                              </button>
                          </div>
                      </div>
                  </div>
              </div>
          )}

          {/* DASHBOARD INPUT (When empty) */}
          {!result && !loadingStep && mode !== 'news' && (!socialPost || mode !== 'social') && (
            <div className="max-w-4xl mx-auto px-4 pt-[8vh] lg:pt-[12vh] pb-32 flex flex-col items-center text-center animate-in fade-in duration-700">
               
               <div className="mb-8 p-3 bg-white border border-gray-100 rounded-2xl shadow-sm inline-flex items-center gap-2">
                   <div className="flex -space-x-2">
                       {[1,2,3,4].map(i => (
                           <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-gray-100 flex items-center justify-center text-[10px] font-bold text-gray-500">
                               {['G','C','P','D'][i-1]}
                           </div>
                       ))}
                   </div>
                   <span className="text-xs font-medium text-gray-500 pr-2">4 AI Agents Ready</span>
               </div>

               <h1 className="text-4xl lg:text-5xl font-bold tracking-tight text-gray-900 mb-4 px-4">
                 How can <span className="text-blue-600">AIBYDM</span> help?
               </h1>
               <p className="text-lg text-gray-500 mb-10 max-w-xl mx-auto leading-relaxed">
                   Orchestrate multiple LLMs to research, code, and design in parallel.
               </p>
               
               {/* MAIN INPUT BOX */}
               <div className="w-full relative group">
                  <div className="absolute -inset-1 bg-gradient-to-r from-blue-100 via-purple-100 to-pink-100 rounded-3xl blur opacity-40 group-hover:opacity-60 transition-opacity duration-500"></div>
                  <div className="relative bg-white shadow-xl shadow-gray-200/50 rounded-3xl p-5 transition-all border border-gray-100 focus-within:ring-2 focus-within:ring-blue-500/10">
                      
                      {/* HEADER: MODE & MODEL SELECTOR */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 px-1 gap-3">
                          <span className="self-start inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-3 py-1 rounded-full">
                              <Zap className="w-3 h-3" />
                              {getModeLabel(mode)} Mode
                          </span>

                          <div className="flex flex-wrap gap-1.5 justify-end">
                              {[Platform.GEMINI, Platform.CHATGPT, Platform.PERPLEXITY, Platform.DEEPSEEK, Platform.CLAUDE].map(p => (
                                  <button
                                    key={p}
                                    onClick={() => togglePlatform(p)}
                                    className={`text-[10px] px-2.5 py-1 rounded-md border transition-all font-medium ${
                                        activePlatforms.includes(p) 
                                        ? 'bg-gray-900 border-gray-900 text-white' 
                                        : 'bg-white border-gray-200 text-gray-500 hover:border-gray-300'
                                    }`}
                                  >
                                      {p}
                                  </button>
                              ))}
                          </div>
                      </div>

                      <textarea
                        ref={textareaRef}
                        value={mainInput}
                        onChange={(e) => setMainInput(e.target.value)}
                        placeholder={getPlaceholder()}
                        className="w-full bg-transparent text-lg lg:text-xl placeholder-gray-300 text-gray-900 resize-none focus:outline-none max-h-[200px] py-2 font-medium leading-relaxed"
                        rows={1}
                        onKeyDown={(e) => {
                            if(e.key === 'Enter' && !e.shiftKey) {
                                e.preventDefault();
                                handleSubmit();
                            }
                        }}
                      />
                      
                      {sources.length > 0 && (
                          <div className="flex flex-wrap gap-2 mb-4 mt-2">
                              {sources.map(s => (
                                  <div key={s.id} className="flex items-center gap-1.5 bg-gray-50 text-xs font-medium text-gray-700 px-3 py-1.5 rounded-lg border border-gray-200 animate-in zoom-in duration-200">
                                      {s.type === 'image' ? <ImageIcon className="w-3.5 h-3.5 text-purple-500"/> : <FileText className="w-3.5 h-3.5 text-blue-500" />}
                                      <span className="max-w-[120px] truncate">{s.name}</span>
                                      <button onClick={() => removeSource(s.id)}><X className="w-3.5 h-3.5 hover:text-red-500 transition-colors" /></button>
                                  </div>
                              ))}
                          </div>
                      )}

                      <div className="flex justify-between items-center mt-4 pt-4 border-t border-gray-50">
                          <div className="flex items-center gap-2">
                              <button 
                                onClick={() => setShowContext(!showContext)}
                                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${showContext ? 'bg-blue-50 text-blue-600' : 'bg-gray-50 text-gray-500 hover:bg-gray-100'}`}
                              >
                                  <Layers className="w-3.5 h-3.5" />
                                  <span className="hidden sm:inline">{showContext ? 'Hide Context' : 'Add Context'}</span>
                              </button>
                              <button 
                                onClick={() => fileInputRef.current?.click()}
                                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gray-50 text-gray-500 text-xs font-semibold hover:bg-gray-100 transition-colors"
                              >
                                  <Upload className="w-3.5 h-3.5" />
                                  <span className="hidden sm:inline">Attach</span>
                              </button>
                              <input 
                                type="file" 
                                ref={fileInputRef} 
                                onChange={handleFileUpload} 
                                className="hidden" 
                                accept=".jpg,.jpeg,.png,.webp,.csv,.tsv,.txt,.json,.py,.sql"
                              />
                          </div>
                          
                          <button 
                             onClick={handleSubmit}
                             disabled={!mainInput.trim() && sources.length === 0}
                             className="group bg-blue-600 hover:bg-blue-700 text-white rounded-full p-3 disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-lg shadow-blue-500/30 hover:shadow-blue-500/40 hover:scale-105 active:scale-95"
                          >
                             <ArrowRight className="w-5 h-5 group-hover:translate-x-0.5 transition-transform" />
                          </button>
                      </div>

                      {showContext && (
                          <div className="mt-4 animate-in slide-in-from-top-2">
                              <textarea
                                value={contextInput}
                                onChange={(e) => setContextInput(e.target.value)}
                                placeholder="Paste system constraints, error logs, or schema details..."
                                className="w-full bg-gray-50/50 rounded-xl p-4 text-sm font-mono text-gray-600 focus:outline-none focus:ring-1 focus:ring-gray-200 border border-gray-100"
                                rows={2}
                              />
                          </div>
                      )}
                  </div>
               </div>

               {/* Quick Actions */}
               <div className="mt-10 flex flex-wrap justify-center gap-3 px-2">
                   <SuggestionPill label="Debug Code" icon={<Bug className="w-3.5 h-3.5 text-red-500"/>} onClick={() => { setMode('debug'); setMainInput('Identify the memory leak in this recursive function...'); }} />
                   <SuggestionPill label="Architecture Graph" icon={<Network className="w-3.5 h-3.5 text-purple-500"/>} onClick={() => { setMode('visual'); setMainInput('Create a Knowledge Graph for a Logistics Supply Chain'); }} />
                   <SuggestionPill label="SQL Tuning" icon={<Database className="w-3.5 h-3.5 text-blue-500"/>} onClick={() => { setMode('sql'); setMainInput('Optimize this Snowflake query for large partitioning...'); }} />
               </div>

            </div>
          )}

          {/* RESULT VIEW */}
          {result && !loadingStep && (
            <div className="max-w-6xl mx-auto w-full px-4 lg:px-8 py-8 pb-32 animate-in slide-in-from-bottom-5 duration-500">
                <ResponsePanel result={result} mode={mode} />
            </div>
          )}
        </div>

      </main>

      <SettingsDrawer 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
        apiKeys={apiKeys}
        setApiKeys={setApiKeys}
      />
    </div>
  );
}

const SuggestionPill = ({ label, icon, onClick }: any) => (
    <button onClick={onClick} className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-full shadow-sm hover:shadow-md hover:border-blue-200 transition-all text-xs font-semibold text-gray-600">
        <span>{icon}</span>
        {label}
    </button>
);

export default App;